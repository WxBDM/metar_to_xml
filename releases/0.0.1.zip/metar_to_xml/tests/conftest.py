import pytest
from tests.fixtures.metars import *
from tests.fixtures.parsed_metars import *
